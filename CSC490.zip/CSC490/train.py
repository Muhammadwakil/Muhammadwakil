from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import mysql.connector
import cv2
import os
import numpy as np


class Train:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1300x710+0+0")
        self.root.iconbitmap('py.ico')
        self.root.title("Face Recognition System")

        # Title
        title_lbl = Label(self.root, text="TRAIN DATA SET", font=("times new roman", 38, "bold"), fg="green", bg="sky blue")
        title_lbl.place(x=0, y=0, width=1300, height=55)

        # Top Image
        img_top = Image.open("img/ex1.jpg").resize((1300, 300), Image.LANCZOS)
        self.photoimg_top = ImageTk.PhotoImage(img_top)
        Label(self.root, image=self.photoimg_top).place(x=0, y=55, width=1300, height=300)

        # Train Button
        Button(self.root, text='TRAIN DATA', command=self.train_classifier, cursor="hand2",
               font=("times new roman", 30, "bold"), bg="sky blue", fg="black").place(x=0, y=355, width=1300, height=85)

        # Bottom Image
        img_bottom = Image.open("img/ex2.jpg").resize((1300, 300), Image.LANCZOS)
        self.photoimg_bottom = ImageTk.PhotoImage(img_bottom)
        Label(self.root, image=self.photoimg_bottom).place(x=0, y=440, width=1300, height=300)

    def train_classifier(self):
        data_dir = "data"

        # Check if data directory exists
        if not os.path.exists(data_dir):
            messagebox.showerror("Error", "Data directory not found!")
            return

        # Initialize variables
        faces = []
        ids = []
        path = [os.path.join(data_dir, file) for file in os.listdir(data_dir) if file.endswith(".jpg")]

        if len(path) == 0:
            messagebox.showerror("Error", "No image data found in the directory!")
            return

        try:
            # Process images
            for image in path:
                try:
                    img = Image.open(image).convert('L')  # Convert to grayscale
                    imageNp = np.array(img, 'uint8')  # Convert to numpy array
                    id = int(os.path.split(image)[1].split(".")[1])  # Extract ID from filename

                    faces.append(imageNp)
                    ids.append(id)
                except Exception as e:
                    print(f"Skipping file {image}: {e}")  # Log and skip invalid files

            # Train classifier
            ids = np.array(ids)
            clf = cv2.face.LBPHFaceRecognizer_create()
            clf.train(faces, ids)
            clf.write("classifier.xml")

            cv2.destroyAllWindows()
            messagebox.showinfo("Result", "Training Dataset Completed Successfully!")

        except Exception as e:
            messagebox.showerror("Error", f"Training failed due to: {str(e)}")


if __name__ == "__main__":
    root = Tk()
    obj = Train(root)
    root.mainloop()
